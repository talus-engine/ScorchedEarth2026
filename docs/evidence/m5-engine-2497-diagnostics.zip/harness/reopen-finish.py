exec(open('/private/tmp/indigo-m5-engine/save-reopen.py').read().split('out=Path')[0])
out=Path('/private/tmp/indigo-m5-engine/docs/evidence/m5-save-reopen-2.json');r=json.loads(out.read_text());wid=r['before']['worldId']
print(call('engine_continue_game',{'worldId':wid}),flush=True)
s=wait_state(lambda s:s['worldId']==wid and s['match'] and s['match']['phase']=='finished' and s['ui'].get('finished'),120)
r['after']=s;r['cameraAfter']=call('engine_camera',{});r['context']=call('engine_describe_context');out.write_text(json.dumps(r,indent=2))
print('reopened',r['cameraAfter'],flush=True)
