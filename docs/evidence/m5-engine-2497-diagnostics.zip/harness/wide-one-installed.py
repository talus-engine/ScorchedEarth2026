import sys,json
from pathlib import Path
sys.path.insert(0,'/Users/tonygermaneri/gh/indigo/tools')
from bridge import call
p=Path('/Users/tonygermaneri/gh/indigo/docs/evidence/m5-osx2497-one-wide.json');assert not p.exists()
s="""const cfg=JSON.parse(await talus.files.readText('Game/arena.json'));talus.world.fill({x:6080,y:200,w:400,h:16},'STONE');talus.world.fill({x:6200,y:199,w:48,h:1},'STONE');const e=await talus.entities.spawn(cfg.tankTemplate,6150,150);if(!e||!await e.whenLive({timeoutTicks:600}))throw new Error('not live');await talus.sleepTicks(90);const before=e.snapshot(),legs=[];for(const d of [1,-1]){const rows=[];for(let i=0;i<300;i++){const s=e.snapshot();e.setVelocity(d*55,s.vy);if(i%6===0)rows.push(s);await talus.sleepTicks(1)}e.setVelocity(0,0);await talus.sleepTicks(30);legs.push({rows,end:e.snapshot()})}const result={before,legs};e.despawn();return result"""
r=call('engine_run_script',{'source':s,'timeoutMs':120000},timeout=130)['value'];r['checks']={'right':r['legs'][0]['end']['x']>6267,'left':r['legs'][1]['end']['x']<6181,'stepObserved':min(s['y']for s in r['legs'][0]['rows'])<185,'healthy':all(v['end']['health']==100 for v in r['legs'])};p.write_text(json.dumps(r,indent=2));print(r['checks'],flush=True);assert all(r['checks'].values())
