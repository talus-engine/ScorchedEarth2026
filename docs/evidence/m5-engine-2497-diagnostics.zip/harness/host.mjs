import { _electron } from '/Users/tonygermaneri/gh/foxtrot/node_modules/playwright/index.mjs'
import { existsSync, readFileSync, writeFileSync, appendFileSync, unlinkSync } from 'node:fs'
const dir='/private/tmp/indigo-m5-engine'
const profile=process.env.DIAG_PROFILE||`${dir}/profile`
const app=await _electron.launch({executablePath:process.env.DIAG_APP||'/Applications/Talus.app/Contents/MacOS/Talus',args:['--disable-backgrounding-occluded-windows','--disable-renderer-backgrounding','--disable-background-timer-throttling'],env:{...process.env,TALUS_EDITOR_USER_DATA:profile,TALUS_EDITOR_NO_MOUNT:process.env.TALUS_EDITOR_NO_MOUNT??'1',TALUS_EDITOR_BRIDGE_WS_PORT:'18801',TALUS_EDITOR_BRIDGE_NFS_PORT:'19049',TALUS_EDITOR_BRIDGE_MCP_PORT:'18802'},timeout:60000})
await app.evaluate(({BrowserWindow})=>BrowserWindow.getAllWindows()[0].setContentSize(1600,968))
const page=await app.firstWindow()
page.on('console',m=>appendFileSync(`${dir}/console.log`,`${m.type()} ${m.text()}\n`))
page.on('pageerror',e=>appendFileSync(`${dir}/errors.log`,`${e}\n`))
await page.waitForLoadState('domcontentloaded')
writeFileSync(`${dir}/host-ready.json`,JSON.stringify({profile,url:page.url()}))
console.log('Diagnostic app open',profile)
while (true) {
  if (existsSync(`${dir}/command.json`)) {
    const command=JSON.parse(readFileSync(`${dir}/command.json`,'utf8')); unlinkSync(`${dir}/command.json`)
    try {
      if(command.close) {await app.close();writeFileSync(`${dir}/reply.json`,JSON.stringify({ok:true}));break}
      if(command.bounds) {await app.evaluate(({BrowserWindow},b)=>BrowserWindow.getAllWindows()[0].setContentSize(b.width,b.height),command.bounds);writeFileSync(`${dir}/reply.json`,JSON.stringify({ok:true}));continue}
      const value=await page.evaluate(command.source)
      writeFileSync(`${dir}/reply.json`,JSON.stringify({ok:true,value}))
    } catch(e) {writeFileSync(`${dir}/reply.json`,JSON.stringify({ok:false,error:String(e)}))}
  }
  await new Promise(r=>setTimeout(r,100))
}
