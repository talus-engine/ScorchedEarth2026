import os,sys,json
from pathlib import Path
os.environ['TALUS_BRIDGE_URL']='http://127.0.0.1:18802';os.environ['TALUS_TOKEN_FILE']='/private/tmp/indigo-m5-engine/profile/bridge-token'
sys.path.insert(0,'/Users/tonygermaneri/gh/indigo/tools')
from bridge import call,WORLD_ID
import m4_support as support
wait=support.wait_state
support.wait_state=lambda predicate,seconds=90:wait(predicate,max(seconds,360))
out=Path('/private/tmp/indigo-m5-engine/docs/evidence/m5-camera-16-ready.json');assert not out.exists()
print(call('write_world_file',{'worldId':WORLD_ID,'path':'Scripts/m5-observer.ts','content':Path('/private/tmp/indigo-m5-engine/observer-focused.ts').read_text()}),flush=True)
r=support.launch('camera-flight-16',16,7,seconds=5,version=5)
r['camera']=call('engine_camera',{})
out.write_text(json.dumps(r,indent=2))
print(json.dumps({'world':r['worldId'],'camera':r['camera'],'error':r['error'],'roster':len(r['roster'])}),flush=True)
