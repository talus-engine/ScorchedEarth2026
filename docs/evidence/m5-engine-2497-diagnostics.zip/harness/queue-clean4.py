import json,time,runpy,os,sys
from pathlib import Path
p=Path('/private/tmp/indigo-m5-engine/docs/evidence/m5-combat-16.json')
for i in range(600):
    try:r=json.loads(p.read_text())
    except (FileNotFoundError,json.JSONDecodeError):time.sleep(1);continue
    if 'after' in r:break
    time.sleep(1)
assert 'after' in r
os.environ['TALUS_BRIDGE_URL']='http://127.0.0.1:18802';os.environ['TALUS_TOKEN_FILE']='/private/tmp/indigo-m5-engine/profile/bridge-token';sys.path.insert(0,'/Users/tonygermaneri/gh/indigo/tools')
from audit_m2 import script
from bridge import call
# Save only between shots, then preserve the final sixteen-tank run.
if r['after']['match']['phase']!='finished':
    q=call('engine_run_script',{'source':"for(let t=0;t<900;t++){const m=talus.state.getJson('indigo.match');if(m.phase==='turn'&&!talus.projectiles.find().length){talus.sim.paused=true;return true}await talus.sleepTicks(1)}throw new Error('no safe boundary')",'timeoutMs':120000},timeout=130)
    assert q.get('value')
print(call('engine_key',{'key':'s','modifiers':['meta'],'settleMs':2000}),flush=True)
runpy.run_path('/private/tmp/indigo-m5-engine/start-clean4.py',run_name='__main__')
runpy.run_path('/private/tmp/indigo-m5-engine/combat-clean4.py',run_name='__main__')
