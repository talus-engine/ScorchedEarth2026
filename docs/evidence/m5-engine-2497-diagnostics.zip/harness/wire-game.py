from pathlib import Path
root=Path('/Users/tonygermaneri/gh/indigo')
p=root/'world/Scripts/match.ts'
s=p.read_text()
a=s.index('  function frameRoster() {');b=s.index('  function movementVelocity',a)
s=s[:a]+'''  function frameRoster(focus?: { x: number, y: number }) {
    if (!match || !arena) return
    const alive = match.roster.filter((p: any) => !p.eliminated)
    const points = alive.map((p: any) => (p.entityId ? entity(p)?.position : null)
      || { x: p.spawnX, y: arena.surfaceBand.top + arena.surfaceBand.height / 2 })
    if (!points.length) { talus.camera.frame(null); return }
    const left = Math.min(...points.map((p: any) => p.x)), right = Math.max(...points.map((p: any) => p.x))
    const top = Math.min(...points.map((p: any) => p.y)), bottom = Math.max(...points.map((p: any) => p.y))
    const half = arena.combat.tankHalfWidth
    const result = talus.camera.frame({ bounds: { x: left - half, y: top - half,
      w: right - left + half * 2, h: bottom - top + half * 2 }, padding: 32, preferVisible: true })
    if (!result?.fitsSimulation) throw new Error('The surviving roster exceeds the supported simulation frame')
    // Zoom/frame use the real renderer and engine ring. A small window may
    // clip the view, but the residency constraint always takes priority.
    const notice = result.fitsViewport ? '' : 'Window too small to show every tank; all tanks remain active.'
    if (match.frameNotice !== notice) { match.frameNotice = notice; talus.ui.set('frameNotice', notice) }
    talus.camera.centerOn(focus || { x: (left + right) / 2, y: (top + bottom) / 2 })
  }
''' + s[b:]
s=s.replace("lastHit: match.lastHit || '',", "lastHit: match.lastHit || '', frameNotice: match.frameNotice || '',")
s=s.replace('    talus.camera.centerOn(p)\n', '    frameRoster(p)\n')
s=s.replace("arena = JSON.parse((await talus.files.readText('Game/arena.json'))!)", "arena = JSON.parse((await talus.files.readText('Game/arena.json'))!)\n      talus.camera.setZoom(0.25); talus.camera.follow('off')")
s=s.replace("    if (!booted || booting || !match || match.phase === 'fault') return\n    ticks++", "    if (match && arena && match.phase !== 'fault') {\n      const focus = match.phase === 'flight' ? shot?.snapshot() : match.phase === 'settling' ? match.impact : null\n      frameRoster(focus || undefined)\n    }\n    if (!booted || booting || !match || match.phase === 'fault') return\n    ticks++")
s=s.replace('      const s = shot?.snapshot(); if (s) talus.camera.centerOn(s.x, s.y)\n', '')
s=s.replace('const tank = entity(current()), s = tank.snapshot(); frameRoster()', 'const tank = entity(current()), s = tank.snapshot()')
p.write_text(s)
p=root/'world/Menus/hud.html';s=p.read_text();s=s.replace('<body>', '<body>')
# Add a bound notice inside the existing HUD root after inspecting its markup.
(root/'world/Scripts/match.ts').write_text((root/'world/Scripts/match.ts').read_text())
