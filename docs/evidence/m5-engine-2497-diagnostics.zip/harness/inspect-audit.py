import os,sys,json
from pathlib import Path
os.environ['TALUS_BRIDGE_URL']='http://127.0.0.1:18802';os.environ['TALUS_TOKEN_FILE']='/private/tmp/indigo-m5-engine/profile/bridge-token'
sys.path.insert(0,'/Users/tonygermaneri/gh/indigo/tools')
from audit_m2 import script
r=script("return talus.state.getJson('m5.audit')")
print(json.dumps({'ticks':r['ticks'],'bad':r['bad'][:3],'badCount':len(r['bad']),'outside':r['outside'],'transitions':r['transitions']},indent=2))
