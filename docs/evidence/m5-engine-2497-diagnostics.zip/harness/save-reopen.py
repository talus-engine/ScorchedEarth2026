import os,sys,json,time
from pathlib import Path
os.environ['TALUS_BRIDGE_URL']='http://127.0.0.1:18802';os.environ['TALUS_TOKEN_FILE']='/private/tmp/indigo-m5-engine/profile/bridge-token'
sys.path.insert(0,'/Users/tonygermaneri/gh/indigo/tools')
from bridge import call
from audit_m2 import script
from m4_support import state,wait_state
out=Path('/private/tmp/indigo-m5-engine/docs/evidence/m5-save-reopen-2.json');assert not out.exists()
r={'before':state(),'cameraBefore':call('engine_camera',{})};wid=r['before']['worldId']
r['save']=call('engine_key',{'key':'s','modifiers':['meta'],'settleMs':2500});out.write_text(json.dumps(r,indent=2))
print('saved',r['save'],flush=True)
call('engine_set_mode',{'mode':'menu'});time.sleep(4)
print(call('engine_continue_game',{'worldId':wid}),flush=True)
s=wait_state(lambda s:s['worldId']==wid and s['match'] and s['match']['phase']=='finished' and s['ui'].get('finished'),120)
r['after']=s;r['cameraAfter']=call('engine_camera',{});r['context']=call('engine_describe_context');out.write_text(json.dumps(r,indent=2))
print('reopened',r['cameraAfter'],flush=True)
