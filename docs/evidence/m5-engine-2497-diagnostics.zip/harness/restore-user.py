import sys,json,time
from pathlib import Path
sys.path.insert(0,'/Users/tonygermaneri/gh/indigo/tools')
from bridge import call,WORLD_ID
from audit_m2 import script
from m4_support import launch
backup=json.loads(Path('/private/tmp/indigo-m5-engine/original-installed-state.json').read_text());items=backup['results'][0]['rows']
for key,value in items:script('talus.installed.set('+json.dumps(key)+','+value+');return true')
time.sleep(1)
prefs=json.loads(next(v for k,v in items if k=='indigo'))
r=launch('M5 ready',prefs['computers'],7,seconds=prefs['turnSeconds'],names=prefs['namesText'].split('\n'),version=5)
r['save']=call('engine_key',{'key':'s','modifiers':['meta'],'settleMs':2000});r['camera']=call('engine_camera',{})
current=call('run_sql_readonly',{'sql':"SELECT key,value_json FROM installed_game_state WHERE game_id='"+WORLD_ID+"'"})
a={k:json.loads(v)for k,v in items};b={k:json.loads(v)for k,v in current['results'][0]['rows']};r['preferencesAndScoresRestored']=a==b;assert a==b
Path('/Users/tonygermaneri/gh/indigo/docs/evidence/m5-osx2497-user-ready.json').write_text(json.dumps(r,indent=2));print('READY',r['worldId'],'restored',r['preferencesAndScoresRestored'],'zoom',r['camera']['zoom'],flush=True)
