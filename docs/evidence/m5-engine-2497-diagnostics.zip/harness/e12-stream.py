import sys,os,json
from pathlib import Path
os.environ['TALUS_BRIDGE_URL']='http://127.0.0.1:18802';os.environ['TALUS_TOKEN_FILE']='/private/tmp/indigo-m5-engine/profile/bridge-token'
sys.path.insert(0,'/Users/tonygermaneri/gh/indigo/tools')
from bridge import call
def script(source):
 r=call('engine_run_script',{'source':source,'timeoutMs':240000},timeout=250)
 if r.get('error'): raise RuntimeError(r['error'])
 return r.get('value')
out=Path('/private/tmp/indigo-m5-engine/docs/evidence/m5-e12-streamed-1.json')
assert not out.exists()
r={}
call('engine_step', {'paused':False})
def save():out.write_text(json.dumps(r,indent=2))
r['stream']=script('''
talus.camera.follow('off');talus.camera.centerOn(5200,400);
const e=talus.entities.get(talus.state.get('m5.probeEntity'));
if(!await e.whenLive({timeoutTicks:600}))throw new Error('restore before course');
e.teleport(5050,350); e.setVelocity(0,0); talus.camera.centerOn(5200,400);await talus.sleepTicks(90);
const before=e.snapshot();talus.camera.centerOn(7600,600);await talus.sleepTicks(180);
const away=e.snapshot();talus.camera.centerOn(5200,400);await talus.sleepTicks(180);
return {before,away,after:e.snapshot()};
''');save();print('stream',r['stream'],flush=True)
for name,direction in [('right',1),('left',-1)]:
 r[name]=script('''
const e=talus.entities.get(talus.state.get('m5.probeEntity')), samples=[];
for(let i=0;i<720;i++){const s=e.snapshot();e.setVelocity(DIR*55,s.vy);talus.camera.centerOn(s.x,400);if(i%12===0)samples.push({tick:i,...s});await talus.sleepTicks(1);}
e.setVelocity(0,0);await talus.sleepTicks(30);return {samples,end:e.snapshot()};
'''.replace('DIR',str(direction)));save();print(name,r[name]['end'],flush=True)
r['pass']=r['stream']['away']['residency']=='stored' and r['stream']['after']['liveId']!=r['stream']['before']['liveId'] and 5350<r['right']['end']['x']<5353 and r['left']['end']['x']<5070
save();print('pass',r['pass'],flush=True)
