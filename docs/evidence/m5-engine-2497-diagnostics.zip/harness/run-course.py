import sys,os,runpy
from pathlib import Path
os.environ['TALUS_BRIDGE_URL']='http://127.0.0.1:18802'
os.environ['TALUS_TOKEN_FILE']='/private/tmp/indigo-m5-engine/profile/bridge-token'
sys.path.insert(0,'/Users/tonygermaneri/gh/indigo/tools')
import bridge
bridge.ROOT=Path('/private/tmp/indigo-m5-engine')
(bridge.ROOT/'docs/evidence').mkdir(parents=True,exist_ok=True)
sys.argv=['probe_m5_movement.py','--label','e12-candidate-1','--version','5']
runpy.run_path('/Users/tonygermaneri/gh/indigo/tools/probe_m5_movement.py',run_name='__main__')
