import os,sys,json,time
from pathlib import Path
os.environ['TALUS_BRIDGE_URL']='http://127.0.0.1:18802';os.environ['TALUS_TOKEN_FILE']='/private/tmp/indigo-m5-engine/profile/bridge-token'
sys.path.insert(0,'/Users/tonygermaneri/gh/indigo/tools')
from bridge import call
from audit_m2 import script
out=Path('/private/tmp/indigo-m5-engine/docs/evidence/m5-off-ring-flights-1.json');assert not out.exists()
r={'before':script("return {m:talus.state.getJson('indigo.match'),audit:talus.state.getJson('m5.audit'),camera:talus.camera.view}")};out.write_text(json.dumps(r,indent=2))
for label,vx,vy in [('high',100,-2000),('long',1200,-1200)]:
 shot=script('''const m=talus.state.getJson('indigo.match');const s=talus.projectiles.launch({kind:'rigid-body',independent:true,x:6400,y:500,vx:VX,vy:VY,element:'IRON',bodySizePx:4,gravityScale:1,drag:0,lifetime:30,damage:80,aoeRadius:100,carveRadius:48,carveMode:'erase',detonate:{onTerrain:true,onBody:true},owner:talus.entities.get(m.roster[0].entityId)});return s?.snapshot();'''.replace('VX',str(vx)).replace('VY',str(vy)))
 print(label,shot,flush=True);assert shot
 r[label]={'launch':shot,'samples':[]};out.write_text(json.dumps(r,indent=2))
 for i in range(120):
  time.sleep(.5)
  p=script('return talus.projectiles.get('+str(shot['id'])+')?.snapshot()||null')
  r[label]['samples'].append(p)
  if i%10==0:print(label,'sample',p,flush=True);out.write_text(json.dumps(r,indent=2))
  if p is None:break
 else:raise TimeoutError(label)
 time.sleep(2)
 r[label]['audit']=script("return talus.state.getJson('m5.audit')")
 out.write_text(json.dumps(r,indent=2))
 print(label,'end',[e for e in r[label]['audit']['events'] if e['projectileId']==shot['id']],flush=True)
print('done',flush=True)
