import os,sys,json,time
from pathlib import Path
os.environ['TALUS_BRIDGE_URL']='http://127.0.0.1:18802';os.environ['TALUS_TOKEN_FILE']='/private/tmp/indigo-m5-engine/profile/bridge-token';sys.path.insert(0,'/Users/tonygermaneri/gh/indigo/tools')
from bridge import call
from audit_m2 import script
r={};p=Path('/private/tmp/indigo-m5-engine/docs/evidence/m5-four-resize.json');assert not p.exists()
for width,height in [(800,600),(1600,968)]:
 cmd=Path('/private/tmp/indigo-m5-engine/command.json');reply=Path('/private/tmp/indigo-m5-engine/reply.json')
 reply.unlink(missing_ok=True);cmd.write_text(json.dumps({'bounds':{'width':width,'height':height}}))
 for i in range(100):
  if reply.exists():break
  time.sleep(.1)
 time.sleep(3)
 c=call('engine_camera',{});s=script("const m=talus.state.getJson('indigo.match');return {m,ui:talus.ui.get(),roster:m.roster.map(p=>talus.entities.get(p.entityId).snapshot()),audit:talus.state.getJson('m5.audit')}")
 r[str(width)]={'camera':c,**s};p.write_text(json.dumps(r,indent=2));print(width,c,'bad',len(s['audit']['bad']),flush=True)
