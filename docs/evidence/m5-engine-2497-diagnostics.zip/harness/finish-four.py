import os,sys,json,time,hashlib
from pathlib import Path
os.environ['TALUS_BRIDGE_URL']='http://127.0.0.1:18802';os.environ['TALUS_TOKEN_FILE']='/private/tmp/indigo-m5-engine/profile/bridge-token';sys.path.insert(0,'/Users/tonygermaneri/gh/indigo/tools')
from bridge import call
from audit_m2 import script
from m4_support import state,wait_state
root=Path('/private/tmp/indigo-m5-engine/docs/evidence');combat=root/'m5-combat-4-2.json';out=root/'m5-four-preservation.json';assert not out.exists()
for i in range(600):
 r=json.loads(combat.read_text())
 if 'after' in r:break
 time.sleep(1)
assert r['after']['match']['phase']!='fault'
if r['after']['match']['phase']!='finished':
 script("for(let i=0;i<900;i++){const m=talus.state.getJson('indigo.match');if(m.phase==='turn'&&!talus.projectiles.find().length){talus.sim.paused=true;return m.phase}await talus.sleepTicks(1)}throw new Error('No safe shot boundary')")
r={'worldId':r['after']['worldId'],'audit':r['audit'],'before':state()};wid=r['worldId']
def save():out.write_text(json.dumps(r,indent=2))
def census():
 counts={}
 for y in range(16,20):
  for x in range(84,115):
   counts[f'{x},{y}']=call('engine_test_helper',{'method':'pmapTypeCensusGpu','args':[{'x':x*64,'y':y*64,'w':64,'h':64},0]})['result']['counts']
 return counts
# A real first-shot crater, with body cells excluded: exact STONE occupancy.
def crater():
 return script("let a=[];for(let y=608;y<800;y++)for(let x=6144;x<6272;x++){const c=talus.world.cell(x,y);a.push(c?.element?.name==='STONE'&&!c.body&&!c.entity?1:0)}return a")
r['bottomAfter']=census();r['craterBeforeReopen']=crater();r['cameraBefore']=call('engine_camera',{});r['save']=call('engine_key',{'key':'s','modifiers':['meta'],'settleMs':2500});save();print('saved',r['save'],flush=True)
call('engine_set_mode',{'mode':'menu'})
for i in range(60):
 time.sleep(.5)
 try:
  c=call('engine_describe_context')
  if not c.get('engineBooted',True) or not c.get('world',{}).get('worldId'):break
 except RuntimeError:pass
for i in range(30):
 try:
  call('engine_continue_game',{'worldId':wid});break
 except RuntimeError:time.sleep(1)
r['after']=wait_state(lambda s:s['worldId']==wid and s['match'] and s['match']['phase'] not in ['deploying','booting'] and s['roster'] and all(p and p['health'] is not None for p in s['roster']),180)
time.sleep(5)
r['cameraAfter']=call('engine_camera',{});r['bottomReopened']=census();r['craterReopened']=crater()
b=json.loads((root/'m5-four-refined-bottom-baseline.json').read_text());base={k:v['result']['counts'] for k,v in b['counts'].items()}
r['pass']={'bottomAfter':r['bottomAfter']==base,'bottomReopened':r['bottomReopened']==base,'exactCrater':r['craterBeforeReopen']==r['craterReopened'],'zoom':r['cameraAfter']['zoom']==.25,'noParks':not r['audit']['bad']}
save();print('CHECKS',r['pass'],flush=True)
assert all(r['pass'].values())
