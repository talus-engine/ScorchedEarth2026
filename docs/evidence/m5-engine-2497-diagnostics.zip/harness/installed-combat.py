import sys,json,time
from pathlib import Path
sys.path.insert(0,'/Users/tonygermaneri/gh/indigo/tools')
from bridge import call
from m4_support import launch,begin,state,wait_state
from audit_m2 import script
root=Path('/Users/tonygermaneri/gh/indigo/docs/evidence');out=root/'m5-osx2497-combat.json';assert not out.exists()
for i in range(180):
 p=root/'m5-osx2497-one-wide.json'
 if p.exists():
  assert all(json.loads(p.read_text())['checks'].values());break
 time.sleep(1)
else:raise TimeoutError('wide ledge test')
r={'before':launch('osx2497-combat',2,7,seconds=5,version=5),'frames':[]};wid=r['before']['worldId']
observer=Path('/private/tmp/indigo-m5-engine/observer.ts').read_text()
r['observerWrite']=call('write_world_file',{'worldId':wid,'path':'Scripts/m5-observer.ts','content':observer});time.sleep(3)
r['reloaded']=state();assert [p['id']for p in r['before']['roster']]==[p['id']for p in r['reloaded']['roster']]
out.write_text(json.dumps(r,indent=2));begin()
for i in range(360):
 time.sleep(1);s=state();r['frames'].append(s)
 if i%10==0:print(i,s['match']['phase'],s['match']['turnNumber'],[p['health']for p in s['roster']],flush=True)
 if i%20==0:out.write_text(json.dumps(r,indent=2))
 if s['match']['phase']in ['finished','fault']:break
r['after']=s;r['audit']=script("return talus.state.getJson('m5.audit')");r['camera']=call('engine_camera',{});out.write_text(json.dumps(r,indent=2))
assert s['match']['phase']=='finished' and not s['error'] and not r['audit']['bad']
r['save']=call('engine_key',{'key':'s','modifiers':['meta'],'settleMs':2500});out.write_text(json.dumps(r,indent=2));print('saved',r['save'],flush=True)
assert r['save']['focused']
call('engine_set_mode',{'mode':'menu'});time.sleep(7)
for i in range(30):
 try:call('engine_continue_game',{'worldId':wid});break
 except RuntimeError:time.sleep(1)
r['reopened']=wait_state(lambda s:s['worldId']==wid and s['match'] and s['match']['phase']=='finished' and s['ui'].get('finished'),180)
r['reopenedCamera']=call('engine_camera',{});r['checks']={'finished':True,'noParks':not r['audit']['bad'],'zoom':r['camera']['zoom']==.25 and r['reopenedCamera']['zoom']==.25,'oneSurvivor':sum(p['alive']for p in r['after']['roster'])==1,'stateAfterReopen':[(p['id'],p['health'])for p in r['after']['roster']]==[(p['id'],p['health'])for p in r['reopened']['roster']]}
out.write_text(json.dumps(r,indent=2));print('CHECKS',r['checks'],flush=True);assert all(r['checks'].values())
