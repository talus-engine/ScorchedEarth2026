import os,sys,json,time,concurrent.futures
from pathlib import Path
os.environ['TALUS_BRIDGE_URL']='http://127.0.0.1:18802';os.environ['TALUS_TOKEN_FILE']='/private/tmp/indigo-m5-engine/profile/bridge-token';sys.path.insert(0,'/Users/tonygermaneri/gh/indigo/tools')
from bridge import call
from audit_m2 import script
from m4_support import state,wait_state
root=Path('/private/tmp/indigo-m5-engine/docs/evidence');out=root/'m5-four-preservation-gpu.json';assert not out.exists()
r={'before':state()};wid=r['before']['worldId'];pool=concurrent.futures.ThreadPoolExecutor(1)
def snapshot():
 script("talus.state.set('m5.holdView',true);return true")
 fut=pool.submit(call,'engine_run_script',{'source':"const off=talus.on('tick.sim.pre',()=>talus.camera.centerOn(6400,640));try{for(let i=0;i<3600&&talus.state.get('m5.holdView');i++)await talus.sleepTicks(1)}finally{talus.off(off)}return true",'timeoutMs':120000},timeout=130)
 try:
  time.sleep(5);v=call('engine_camera',{});counts={}
  for y in range(16,20):
   for x in range(84,115):
    counts[f'{x},{y}']=call('engine_test_helper',{'method':'pmapTypeCensusGpu','args':[{'x':x*64,'y':y*64,'w':64,'h':64},0]})['result']['counts']
  crater=call('engine_test_helper',{'method':'pmapTypeCensusGpu','args':[{'x':6144,'y':608,'w':128,'h':192},25000]})['result']
  return {'camera':v,'counts':counts,'crater':crater}
 finally:
  script("talus.state.set('m5.holdView',false);return true");fut.result()
r['beforeReopen']=snapshot();r['save']=call('engine_key',{'key':'s','modifiers':['meta'],'settleMs':2500});out.write_text(json.dumps(r,indent=2));print('saved',flush=True)
call('engine_set_mode',{'mode':'menu'});time.sleep(7)
for i in range(30):
 try:call('engine_continue_game',{'worldId':wid});break
 except RuntimeError:time.sleep(1)
r['after']=wait_state(lambda s:s['worldId']==wid and s['match'] and s['match']['phase']=='finished' and s['ui'].get('finished'),180)
r['afterReopen']=snapshot()
b=json.loads((root/'m5-four-refined-bottom-baseline.json').read_text());base={k:v['result']['counts']for k,v in b['counts'].items()}
a=r['beforeReopen'];z=r['afterReopen'];r['pass']={'bottomBefore':a['counts']==base,'bottomAfter':z['counts']==base,'exactCraterStone':a['crater']['where'].get('9',[])==z['crater']['where'].get('9',[]),'zoom':z['camera']['zoom']==.25}
out.write_text(json.dumps(r,indent=2));print('CHECKS',r['pass'],flush=True);assert all(r['pass'].values())
