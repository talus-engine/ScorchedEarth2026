import os,sys,json,time,math,concurrent.futures
from pathlib import Path
os.environ['TALUS_BRIDGE_URL']='http://127.0.0.1:18802';os.environ['TALUS_TOKEN_FILE']='/private/tmp/indigo-m5-engine/profile/bridge-token';sys.path.insert(0,'/Users/tonygermaneri/gh/indigo/tools')
from bridge import call
from audit_m2 import script
from m4_support import state,wait_state
root=Path('/private/tmp/indigo-m5-engine/docs/evidence');out=root/'m5-offring-crater-cpu-preservation.json';assert not out.exists()
f=json.loads((root/'m5-off-ring-flights-16.json').read_text());id=f['long']['launch']['id'];e=next(e for e in f['long']['audit']['events']if e['event']=='detonate' and e['projectileId']==id)
rect={'x':math.floor(e['x'])-96,'y':math.floor(e['y'])-96,'w':192,'h':192}
r={'rect':rect,'impact':e,'before':state()};wid=r['before']['worldId'];pool=concurrent.futures.ThreadPoolExecutor(1)
def snapshot():
 script("talus.state.set('m5.holdCrater',true);talus.state.set('m5.craterReady',false);return true")
 source="const a=talus.sim.anchor({rect:RECT,label:'crater-inspection'});try{if(!await a.whenLoaded({timeoutTicks:900}))throw new Error('Crater not loaded');talus.state.set('m5.craterReady',true);for(let i=0;i<3600&&talus.state.get('m5.holdCrater');i++)await talus.sleepTicks(1)}finally{a.release()}return true".replace('RECT',json.dumps(rect))
 fut=pool.submit(call,'engine_run_script',{'source':source,'timeoutMs':120000},timeout=130)
 try:
  for i in range(100):
   if script("return talus.state.get('m5.craterReady')"):break
   time.sleep(.3)
  time.sleep(1)
  return {'camera':call('engine_camera',{}),'gpu':script("const rect="+json.dumps(rect)+";const counts={},where={};for(let y=rect.y;y<rect.y+rect.h;y++)for(let x=rect.x;x<rect.x+rect.w;x++){const id=talus.world.cell(x,y)?.element?.id;if(!id)continue;counts[id]=(counts[id]||0)+1;(where[id]||=[]).push({x,y})}return {counts,where}"),'audit':script("return talus.state.getJson('m5.audit')")}
 finally:
  script("talus.state.set('m5.holdCrater',false);return true");fut.result()
r['beforeReopen']=snapshot();r['save']=call('engine_key',{'key':'s','modifiers':['meta'],'settleMs':2500});out.write_text(json.dumps(r,indent=2));print('saved',r['beforeReopen']['gpu']['counts'],flush=True)
call('engine_set_mode',{'mode':'menu'});time.sleep(7)
for i in range(30):
 try:call('engine_continue_game',{'worldId':wid});break
 except RuntimeError:time.sleep(1)
r['after']=wait_state(lambda s:s['worldId']==wid and s['match'] and s['match']['phase']=='ready' and s['ui'].get('ready'),180)
r['afterReopen']=snapshot();a=r['beforeReopen'];z=r['afterReopen'];r['pass']={'nonempty':sum(a['gpu']['counts'].values())>1000,'exactStone':a['gpu']['where'].get('9',[])==z['gpu']['where'].get('9',[]),'allMaterial':a['gpu']==z['gpu'],'zoom':z['camera']['zoom']==.25,'allTanksLive':all(p['residency']=='live'for p in r['after']['roster']),'healthIdentity':[(p['id'],p['health'])for p in r['before']['roster']]==[(p['id'],p['health'])for p in r['after']['roster']],'noParks':not a['audit']['bad'] and not z['audit']['bad']}
out.write_text(json.dumps(r,indent=2));print('CHECKS',r['pass'],z['gpu']['counts'],flush=True);assert all(r['pass'].values())
