import os,sys,json
from pathlib import Path
os.environ['TALUS_BRIDGE_URL']='http://127.0.0.1:18802';os.environ['TALUS_TOKEN_FILE']='/private/tmp/indigo-m5-engine/profile/bridge-token';sys.path.insert(0,'/Users/tonygermaneri/gh/indigo/tools')
from bridge import call
from audit_m2 import script
from m4_support import state
p=Path('/private/tmp/indigo-m5-engine/docs/evidence/m5-combat-16.json');r=json.loads(p.read_text());r['after']=state()
r['audit']=script("const {paths,...rest}=talus.state.getJson('m5.audit');return {...rest,pathCount:paths.length}")
r['audit']['paths']=[]
for i in range(0,r['audit']['pathCount'],100):r['audit']['paths']+=script(f"return talus.state.getJson('m5.audit').paths.slice({i},{i+100})")
r['camera']=call('engine_camera',{});p.write_text(json.dumps(r,indent=2))
print('Finished',r['after']['match']['phase'],'turn',r['after']['match']['turnNumber'],'bad',len(r['audit']['bad']),'ticks',r['audit']['ticks'],'samples',len(r['audit']['paths']),flush=True)
