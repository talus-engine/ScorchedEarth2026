import os,sys,json,time
from pathlib import Path
os.environ['TALUS_BRIDGE_URL']='http://127.0.0.1:18802';os.environ['TALUS_TOKEN_FILE']='/private/tmp/indigo-m5-engine/profile/bridge-token';sys.path.insert(0,'/Users/tonygermaneri/gh/indigo/tools')
from bridge import call
from m4_support import wait_state
for x,y,v in [(885,348,'0'),(1105,348,'4'),(885,447,'5'),(1105,447,'7'),(1000,575,'Clean Four 1\nClean Four 2\nClean Four 3\nClean Four 4')]:
 print(call('engine_mouse',{'action':'click','x':x,'y':y}),flush=True)
 print(call('engine_key',{'key':'a','modifiers':['meta']}),flush=True)
 print(call('engine_type',{'text':v}),flush=True)
call('engine_mouse',{'action':'click','x':1125,'y':793})
r=wait_state(lambda s:s['match'] is not None and s['match']['phase']=='ready' and s['ui'].get('ready'),180)
assert len(r['roster'])==4 and r['match']['humans']==0
r['camera']=call('engine_camera',{});Path('/private/tmp/indigo-m5-engine/docs/evidence/m5-clean-four-ready.json').write_text(json.dumps(r,indent=2));print('READY',r['worldId'],flush=True)
import runpy
runpy.run_path('/private/tmp/indigo-m5-engine/combat-clean4.py',run_name='__main__')
