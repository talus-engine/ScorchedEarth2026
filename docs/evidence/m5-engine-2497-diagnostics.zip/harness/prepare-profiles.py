import os,sys,time,json
from pathlib import Path
os.environ['TALUS_BRIDGE_URL']='http://127.0.0.1:18802';os.environ['TALUS_TOKEN_FILE']='/private/tmp/indigo-m5-engine/profile/bridge-token';sys.path.insert(0,'/Users/tonygermaneri/gh/indigo/tools')
from bridge import call,WORLD_ID
from install_m1 import save_template
from audit_m2 import script
print(call('engine_set_mode',{'mode':'editor','template':WORLD_ID}),flush=True)
for i in range(120):
 time.sleep(1)
 try:
  c=call('engine_describe_context')['world']
  if c['engineBooted'] and c['isEditorMode'] and c['templateId']==WORLD_ID:break
 except RuntimeError:pass
else:raise TimeoutError('editor')
low=save_template('diagnostic/m5-low-step','indigo/m5-tank',{'characterController':{'offset':1.5,'autostepHeight':2,'snapToGroundDistance':3,'maxSlopeClimbAngle':0.5235987755982988,'minSlopeSlideAngle':0.6108652381980153}})
Path('/private/tmp/indigo-m5-engine/profile-ids.json').write_text(json.dumps({'low':low}))
print(script('await talus.editor.save();return true'),flush=True)
