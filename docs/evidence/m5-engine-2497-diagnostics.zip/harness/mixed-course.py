import os,sys,json
from pathlib import Path
os.environ['TALUS_BRIDGE_URL']='http://127.0.0.1:18802';os.environ['TALUS_TOKEN_FILE']='/private/tmp/indigo-m5-engine/profile/bridge-token';sys.path.insert(0,'/Users/tonygermaneri/gh/indigo/tools')
from bridge import call
from audit_m2 import script
out=Path('/private/tmp/indigo-m5-engine/docs/evidence/m5-mixed-course.json');assert not out.exists()
def long(s):
 r=call('engine_run_script',{'source':s,'timeoutMs':120000},timeout=130)
 if r.get('error'):raise RuntimeError(r['error'])
 return r['value']
r={}
def save():out.write_text(json.dumps(r,indent=2))
r['course']=long('''const config=JSON.parse(await talus.files.readText('Game/arena.json'));
 let n=talus.world.fill({x:6000,y:200,w:650,h:12},'STONE');
 for(let x=6200;x<6328;x++){const h=Math.floor(Math.min(x-6200,6328-x)/2);if(h<=0)continue;
  if(h>4)n+=talus.world.fill({x,y:200-h+4,w:1,h:h-4},'STONE');n+=talus.world.fill({x,y:200-h,w:1,h:Math.min(4,h)},'SAND');}
 n+=talus.world.fill({x:6400,y:160,w:48,h:40},'STONE');
 const e=await talus.entities.spawn(config.tankTemplate,6100,150);if(!e||!await e.whenLive({timeoutTicks:600}))throw new Error('spawn');
 talus.state.set('m5.mixedActor',e.id);await talus.sleepTicks(120);return {n,start:e.snapshot()};''');save();print('course',r['course'],flush=True)
for direction in [1,-1]:
 r[str(direction)]=long('''const e=talus.entities.get(talus.state.get('m5.mixedActor')),rows=[];
 for(let t=0;t<900;t++){const s=e.snapshot();if(DIR<0&&s.x<6100)break;e.setVelocity(DIR*55,s.vy);if(t%12===0)rows.push({t,...s});await talus.sleepTicks(1);}
 e.setVelocity(0,0);await talus.sleepTicks(30);return {rows,end:e.snapshot()};'''.replace('DIR',str(direction)));save();print(direction,r[str(direction)]['end'],flush=True)
r['audit']=script("return talus.state.getJson('m5.audit')");save()
script("talus.entities.get(talus.state.get('m5.mixedActor')).despawn();return true")
