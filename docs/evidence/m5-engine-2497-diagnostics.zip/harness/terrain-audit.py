import os,sys,json,time
from pathlib import Path
os.environ['TALUS_BRIDGE_URL']='http://127.0.0.1:18802';os.environ['TALUS_TOKEN_FILE']='/private/tmp/indigo-m5-engine/profile/bridge-token';sys.path.insert(0,'/Users/tonygermaneri/gh/indigo/tools')
from bridge import call
from audit_m2 import script
out=Path('/private/tmp/indigo-m5-engine/docs/evidence/m5-four-bottom-baseline.json');assert not out.exists()
r={'worldId':script('return talus.world.id'),'counts':{}}
for y in range(16,20):
 for x in range(84,115):
  c=call('engine_test_helper',{'method':'pmapTypeCensusGpu','args':[{'x':x*64,'y':y*64,'w':64,'h':64},0]})
  r['counts'][f'{x},{y}']=c
 out.write_text(json.dumps(r,indent=2));print('row',y,flush=True)
