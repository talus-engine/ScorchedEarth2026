import os,sys,json,time
from pathlib import Path
os.environ['TALUS_BRIDGE_URL']='http://127.0.0.1:18802';os.environ['TALUS_TOKEN_FILE']='/private/tmp/indigo-m5-engine/profile/bridge-token';sys.path.insert(0,'/Users/tonygermaneri/gh/indigo/tools')
from bridge import call
from m4_support import launch,state
from audit_m2 import script
out=Path('/private/tmp/indigo-m5-engine/docs/evidence/m5-profiles-packaged-2.json');assert not out.exists()
r={'initial':launch('profiles-4-b',4,7,seconds=5,version=5)}
def save():out.write_text(json.dumps(r,indent=2))
def long(source):
 x=call('engine_run_script',{'source':source,'timeoutMs':120000},timeout=130)
 if x.get('error'):raise RuntimeError(x['error'])
 return x['value']
low=json.loads(Path('/private/tmp/indigo-m5-engine/profile-ids.json').read_text())['low']
ids=json.loads(Path('/Users/tonygermaneri/gh/indigo/assets/m5-ids.json').read_text())
r['camera']=call('engine_camera',{});save();print('ready',r['initial']['worldId'],r['camera'],flush=True)
# Two lanes in the existing camera ring, above the natural terrain. Neither
# diagnostic actor belongs to the scored roster.
r['course']=script('''let filled=0;for(const y of [300,440]){
 filled+=talus.world.fill({x:5980,y,w:700,h:16},'STONE');
 for(const o of [{x:6090,h:1,w:1},{x:6160,h:4,w:48},{x:6240,h:10,w:48},{x:6360,h:40,w:48}])filled+=talus.world.fill({x:o.x,y:y-o.h,w:o.w,h:o.h},'STONE');
}return filled;''');save()
for reverse in [False,True]:
 key='reverse'if reverse else'forward';r[key]={}
 specs=[{'name':'high','template':ids['tank'],'y':250},{'name':'low','template':low,'y':390}]
 if reverse:specs.reverse()
 r[key]['spawn']=long('''const es=[];for(const p of SPECS){const e=await talus.entities.spawn(p.template,6040,p.y);if(!e||!await e.whenLive({timeoutTicks:600}))throw new Error('spawn');es.push({name:p.name,id:e.id});}
 talus.state.setJson('m5.profileActors',es);await talus.sleepTicks(90);return es.map(p=>({...p,s:talus.entities.get(p.id).snapshot()}));'''.replace('SPECS',json.dumps(specs)));save()
 for direction in [1,-1]:
  r[key][str(direction)]=long('''const es=talus.state.getJson('m5.profileActors'),rows=[];for(let t=0;t<720;t++){
   for(const p of es){const e=talus.entities.get(p.id),s=e.snapshot();e.setVelocity(DIR*55,s.vy);if(t%30===0)rows.push({t,name:p.name,...s});}await talus.sleepTicks(1);}
   for(const p of es)talus.entities.get(p.id).setVelocity(0,0);await talus.sleepTicks(30);
   return {rows,end:es.map(p=>({name:p.name,...talus.entities.get(p.id).snapshot()}))};'''.replace('DIR',str(direction)));save();print(key,direction,r[key][str(direction)]['end'],flush=True)
 script("for(const p of talus.state.getJson('m5.profileActors'))talus.entities.get(p.id).despawn();return true")
r['audit']=script("return talus.state.getJson('m5.audit')");r['after']=state();save();print('done bad',len(r['audit']['bad']),flush=True)
