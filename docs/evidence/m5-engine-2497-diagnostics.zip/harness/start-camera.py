import os,sys,json
from pathlib import Path
os.environ['TALUS_BRIDGE_URL']='http://127.0.0.1:18802';os.environ['TALUS_TOKEN_FILE']='/private/tmp/indigo-m5-engine/profile/bridge-token'
sys.path.insert(0,'/Users/tonygermaneri/gh/indigo/tools')
from bridge import call,WORLD_ID
from m4_support import launch
observer='''
if(!talus.editor.available){
 let ticks=0,bad=[],transitions=[],paths=[],events=[],seen={},outside=0;
 talus.on('entity.residency',e=>{const m=talus.state.getJson('indigo.match');if(m?.roster.some(p=>p.entityId===e.entityKey))transitions.push(JSON.parse(JSON.stringify(e)))});
 for(const name of ['launch','detonate','hit','end'])talus.on('projectile.'+name,e=>events.push({event:name,...JSON.parse(JSON.stringify(e)),clock:talus.sim.clock}));
 talus.on('tick.sim.post',()=>{
  const m=talus.state.getJson('indigo.match');if(!m)return;ticks++;
  const v=talus.camera.view,b=v.simulationBounds,rs=[];
  for(const p of m.roster){if(!p.entityId||p.eliminated)continue;const s=talus.entities.get(p.entityId).snapshot();if(!s?.alive)continue;
   const key=s.id+':'+s.residency;if(seen[s.id]!==key){seen[s.id]=key;transitions.push({id:s.id,residency:s.residency,tick:ticks,phase:m.phase})}
   const inside=b&&s.x-20>=b.x&&s.x+20<b.x+b.w&&s.y-20>=b.y&&s.y+20<b.y+b.h;
   if(s.residency!=='live'||!inside){if(bad.length<1000)bad.push({tick:ticks,phase:m.phase,s,b})}
   rs.push({id:s.id,x:s.x,y:s.y,health:s.health,live:s.liveId});
  }
  const shots=talus.projectiles.find().map(s=>s.snapshot()).filter(Boolean);
  for(const s of shots)if(b&&(s.x<b.x||s.x>=b.x+b.w||s.y<b.y||s.y>=b.y+b.h))outside++;
  if(ticks%12===0&&paths.length<3000)paths.push({tick:ticks,phase:m.phase,zoom:v.zoom,viewport:v.viewport,ring:b,roster:rs,shots});
  if(ticks%60===0)talus.state.setJson('m5.audit',{ticks,bad,transitions,paths,events,outside});
 });
}
'''
Path('/private/tmp/indigo-m5-engine/observer.ts').write_text(observer)
print(call('write_world_file',{'worldId':WORLD_ID,'path':'Scripts/m5-observer.ts','content':observer}),flush=True)
r=launch('camera-flight-2',2,7,seconds=5,version=5)
r['camera']=call('engine_camera',{})
Path('/private/tmp/indigo-m5-engine/docs/evidence/m5-camera-2-ready.json').write_text(json.dumps(r,indent=2))
print(json.dumps({'world':r['worldId'],'camera':r['camera'],'error':r['error']}),flush=True)
