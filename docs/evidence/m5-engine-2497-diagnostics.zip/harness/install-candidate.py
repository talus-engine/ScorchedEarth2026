import os,sys,time,json,runpy
from pathlib import Path
os.environ['TALUS_BRIDGE_URL']='http://127.0.0.1:18802';os.environ['TALUS_TOKEN_FILE']='/private/tmp/indigo-m5-engine/profile/bridge-token'
sys.path.insert(0,'/Users/tonygermaneri/gh/indigo/tools')
from bridge import call,WORLD_ID
print(call('engine_set_mode',{'mode':'editor','template':WORLD_ID}),flush=True)
for i in range(120):
 time.sleep(1)
 try:
  c=call('engine_describe_context')['world']
  if c['engineBooted'] and c['isEditorMode'] and c['templateId']==WORLD_ID:break
 except RuntimeError:pass
else:raise TimeoutError('editor')
# This installation changes only M5 templates, files and fixture IDs.
runpy.run_path('/Users/tonygermaneri/gh/indigo/tools/install_m5.py',run_name='__main__')
