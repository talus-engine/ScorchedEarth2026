import os,sys,json,time
from pathlib import Path
os.environ['TALUS_BRIDGE_URL']='http://127.0.0.1:18802';os.environ['TALUS_TOKEN_FILE']='/private/tmp/indigo-m5-engine/profile/bridge-token'
sys.path.insert(0,'/Users/tonygermaneri/gh/indigo/tools')
from bridge import call
from m4_support import begin,state
from audit_m2 import script
out=Path('/private/tmp/indigo-m5-engine/docs/evidence/m5-combat-4-2.json');assert not out.exists()
r={'before':state(),'frames':[]};out.write_text(json.dumps(r,indent=2))
begin()
for i in range(360):
 time.sleep(1)
 s=state();m=s['match'];r['frames'].append(s)
 if i%10==0:print(i,m['phase'],m['turnNumber'],s['error'],[(p['x'],p['y'],p['health'],p['residency']) for p in s['roster']],flush=True)
 if i%20==0:out.write_text(json.dumps(r,indent=2))
 if m['phase']in['fault','finished']:break
r['after']=s;r['audit']=script("return talus.state.getJson('m5.audit')");r['camera']=call('engine_camera',{});out.write_text(json.dumps(r,indent=2))
print('END',m['phase'],s['error'],'bad',len(r['audit']['bad']),'outside',r['audit']['outside'],flush=True)
